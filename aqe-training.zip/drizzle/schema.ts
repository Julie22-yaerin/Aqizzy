import {
  bigint,
  boolean,
  index,
  int,
  json,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  uniqueIndex,
  varchar,
} from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export const curriculumSessions = mysqlTable("curriculum_sessions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  week: int("week").notNull(),
  sessionNumber: int("sessionNumber").notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  persistenceTarget: varchar("persistenceTarget", { length: 64 }).notNull(),
  introduction: text("introduction").notNull(),
  activeQuestionId: varchar("activeQuestionId", { length: 64 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [uniqueIndex("curriculum_session_number_idx").on(table.sessionNumber)]);

export const questions = mysqlTable("questions", {
  id: varchar("id", { length: 64 }).primaryKey(),
  sessionId: varchar("sessionId", { length: 64 }).notNull(),
  subject: varchar("subject", { length: 80 }).notNull(),
  gradeBand: varchar("gradeBand", { length: 32 }).notNull(),
  difficulty: int("difficulty").notNull(),
  persistenceTarget: varchar("persistenceTarget", { length: 64 }).notNull(),
  questionText: text("questionText").notNull(),
  answerType: varchar("answerType", { length: 32 }).notNull(),
  acceptedAnswers: json("acceptedAnswers").$type<string[]>().notNull(),
  hint1: text("hint1").notNull(),
  hint2: text("hint2").notNull(),
  hint3: text("hint3").notNull(),
  solution: text("solution").notNull(),
  recoveryQuestion: text("recoveryQuestion").notNull(),
  recoveryAnswers: json("recoveryAnswers").$type<string[]>().notNull(),
  recoverySolution: text("recoverySolution").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => [index("question_session_idx").on(table.sessionId), index("question_target_idx").on(table.persistenceTarget)]);

export const studentSessions = mysqlTable("student_sessions", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => users.id),
  sessionId: varchar("sessionId", { length: 64 }).notNull().references(() => curriculumSessions.id),
  week: int("week").notNull(),
  sessionNumber: int("sessionNumber").notNull(),
  completed: boolean("completed").default(false).notNull(),
  startedAt: timestamp("startedAt").defaultNow().notNull(),
  completedAt: timestamp("completedAt"),
  durationSeconds: int("durationSeconds").default(0).notNull(),
  attemptCount: int("attemptCount").default(0).notNull(),
  meaningfulAttemptCount: int("meaningfulAttemptCount").default(0).notNull(),
  hintsUsed: int("hintsUsed").default(0).notNull(),
  strategyChanges: int("strategyChanges").default(0).notNull(),
  recoveryCompleted: boolean("recoveryCompleted").default(false).notNull(),
  reflectionResponse: json("reflectionResponse").$type<{ action?: string; differentApproach?: string }>(),
}, (table) => [
  uniqueIndex("student_session_unique_idx").on(table.studentId, table.sessionId),
  index("student_session_student_idx").on(table.studentId),
]);

export const attempts = mysqlTable("attempts", {
  id: int("id").autoincrement().primaryKey(),
  studentId: int("studentId").notNull().references(() => users.id),
  studentSessionId: int("studentSessionId").notNull().references(() => studentSessions.id),
  questionId: varchar("questionId", { length: 64 }).notNull().references(() => questions.id),
  stage: mysqlEnum("stage", ["primary", "recovery"]).notNull(),
  attemptNumber: int("attemptNumber").notNull(),
  timestampMs: bigint("timestampMs", { mode: "number" }).notNull(),
  timeSpentSeconds: int("timeSpentSeconds").default(0).notNull(),
  answer: text("answer").notNull(),
  correctness: boolean("correctness").notNull(),
  hintRequested: boolean("hintRequested").default(false).notNull(),
  hintNumber: int("hintNumber").default(0).notNull(),
  strategyChanged: boolean("strategyChanged").default(false).notNull(),
  meaningfulAttempt: mysqlEnum("meaningfulAttempt", ["NO_ATTEMPT", "MINIMAL_ATTEMPT", "MEANINGFUL_ATTEMPT", "STRATEGY_CHANGE"]).notNull(),
}, (table) => [index("attempt_student_idx").on(table.studentId), index("attempt_question_idx").on(table.questionId)]);

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;
