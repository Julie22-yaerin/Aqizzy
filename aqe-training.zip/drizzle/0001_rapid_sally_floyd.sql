CREATE TABLE `attempts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentId` int NOT NULL,
	`studentSessionId` int NOT NULL,
	`questionId` varchar(64) NOT NULL,
	`stage` enum('primary','recovery') NOT NULL,
	`attemptNumber` int NOT NULL,
	`timestampMs` int NOT NULL,
	`timeSpentSeconds` int NOT NULL DEFAULT 0,
	`answer` text NOT NULL,
	`correctness` boolean NOT NULL,
	`hintRequested` boolean NOT NULL DEFAULT false,
	`hintNumber` int NOT NULL DEFAULT 0,
	`strategyChanged` boolean NOT NULL DEFAULT false,
	`meaningfulAttempt` enum('NO_ATTEMPT','MINIMAL_ATTEMPT','MEANINGFUL_ATTEMPT','STRATEGY_CHANGE') NOT NULL,
	CONSTRAINT `attempts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `curriculum_sessions` (
	`id` varchar(64) NOT NULL,
	`week` int NOT NULL,
	`sessionNumber` int NOT NULL,
	`title` varchar(160) NOT NULL,
	`persistenceTarget` varchar(64) NOT NULL,
	`introduction` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `curriculum_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `curriculum_session_number_idx` UNIQUE(`sessionNumber`)
);
--> statement-breakpoint
CREATE TABLE `questions` (
	`id` varchar(64) NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`subject` varchar(80) NOT NULL,
	`gradeBand` varchar(32) NOT NULL,
	`difficulty` int NOT NULL,
	`persistenceTarget` varchar(64) NOT NULL,
	`questionText` text NOT NULL,
	`answerType` varchar(32) NOT NULL,
	`acceptedAnswers` json NOT NULL,
	`hint1` text NOT NULL,
	`hint2` text NOT NULL,
	`hint3` text NOT NULL,
	`solution` text NOT NULL,
	`recoveryQuestion` text NOT NULL,
	`recoveryAnswers` json NOT NULL,
	`recoverySolution` text NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `questions_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `student_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`studentId` int NOT NULL,
	`sessionId` varchar(64) NOT NULL,
	`week` int NOT NULL,
	`sessionNumber` int NOT NULL,
	`completed` boolean NOT NULL DEFAULT false,
	`startedAt` timestamp NOT NULL DEFAULT (now()),
	`completedAt` timestamp,
	`durationSeconds` int NOT NULL DEFAULT 0,
	`attemptCount` int NOT NULL DEFAULT 0,
	`meaningfulAttemptCount` int NOT NULL DEFAULT 0,
	`hintsUsed` int NOT NULL DEFAULT 0,
	`strategyChanges` int NOT NULL DEFAULT 0,
	`recoveryCompleted` boolean NOT NULL DEFAULT false,
	`reflectionResponse` json,
	CONSTRAINT `student_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `student_session_unique_idx` UNIQUE(`studentId`,`sessionId`)
);
--> statement-breakpoint
ALTER TABLE `attempts` ADD CONSTRAINT `attempts_studentId_users_id_fk` FOREIGN KEY (`studentId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `attempts` ADD CONSTRAINT `attempts_studentSessionId_student_sessions_id_fk` FOREIGN KEY (`studentSessionId`) REFERENCES `student_sessions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `attempts` ADD CONSTRAINT `attempts_questionId_questions_id_fk` FOREIGN KEY (`questionId`) REFERENCES `questions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `student_sessions` ADD CONSTRAINT `student_sessions_studentId_users_id_fk` FOREIGN KEY (`studentId`) REFERENCES `users`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
ALTER TABLE `student_sessions` ADD CONSTRAINT `student_sessions_sessionId_curriculum_sessions_id_fk` FOREIGN KEY (`sessionId`) REFERENCES `curriculum_sessions`(`id`) ON DELETE no action ON UPDATE no action;--> statement-breakpoint
CREATE INDEX `attempt_student_idx` ON `attempts` (`studentId`);--> statement-breakpoint
CREATE INDEX `attempt_question_idx` ON `attempts` (`questionId`);--> statement-breakpoint
CREATE INDEX `question_session_idx` ON `questions` (`sessionId`);--> statement-breakpoint
CREATE INDEX `question_target_idx` ON `questions` (`persistenceTarget`);--> statement-breakpoint
CREATE INDEX `student_session_student_idx` ON `student_sessions` (`studentId`);