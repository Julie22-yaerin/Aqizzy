import { AuthDialog } from "@/components/AuthDialog";
import { createContext, useContext, useMemo, useState } from "react";

const AuthDialogContext = createContext<{ openLogin: () => void }>({ openLogin: () => undefined });

export function AuthDialogProvider({ children }: { children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  const value = useMemo(() => ({ openLogin: () => setOpen(true) }), []);
  return <AuthDialogContext.Provider value={value}><>{children}</><AuthDialog open={open} onOpenChange={setOpen} /></AuthDialogContext.Provider>;
}

export function useLoginDialog() { return useContext(AuthDialogContext); }
