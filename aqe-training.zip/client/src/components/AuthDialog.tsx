import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { firebaseAuth } from "@/lib/firebase";
import { createUserWithEmailAndPassword, GoogleAuthProvider, sendPasswordResetEmail, signInWithEmailAndPassword, signInWithPopup } from "firebase/auth";
import { AlertCircle, Chrome, Loader2, Mail } from "lucide-react";
import { FormEvent, useState } from "react";
import { useLocation } from "wouter";

function firebaseErrorMessage(error: unknown) {
  const code = typeof error === "object" && error && "code" in error ? String((error as { code: unknown }).code) : "";
  const messages: Record<string, string> = {
    "auth/invalid-credential": "Email hoặc mật khẩu chưa đúng.",
    "auth/invalid-email": "Email chưa đúng định dạng.",
    "auth/email-already-in-use": "Email này đã được đăng ký. Hãy đăng nhập.",
    "auth/weak-password": "Mật khẩu cần có ít nhất 6 ký tự.",
    "auth/popup-closed-by-user": "Cửa sổ Google đã được đóng trước khi hoàn tất.",
    "auth/popup-blocked": "Trình duyệt đã chặn cửa sổ Google. Hãy cho phép popup rồi thử lại.",
    "auth/too-many-requests": "Có quá nhiều lần thử. Hãy chờ một chút rồi thử lại.",
  };
  return messages[code] ?? "Đăng nhập chưa thành công. Hãy thử lại sau.";
}

export function AuthDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (open: boolean) => void }) {
  const [, setLocation] = useLocation();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const continueAfterAuth = () => { onOpenChange(false); if (window.location.pathname === "/") setLocation("/dashboard"); };
  const signInGoogle = async () => { setBusy(true); setError(null); try { await signInWithPopup(firebaseAuth, new GoogleAuthProvider()); continueAfterAuth(); } catch (authError) { setError(firebaseErrorMessage(authError)); } finally { setBusy(false); } };
  const submitEmail = async (event: FormEvent) => { event.preventDefault(); if (!email.trim() || !password) { setError("Hãy nhập email và mật khẩu."); return; } setBusy(true); setError(null); try { if (mode === "signin") await signInWithEmailAndPassword(firebaseAuth, email.trim(), password); else await createUserWithEmailAndPassword(firebaseAuth, email.trim(), password); continueAfterAuth(); } catch (authError) { setError(firebaseErrorMessage(authError)); } finally { setBusy(false); } };
  const resetPassword = async () => { if (!email.trim()) { setError("Hãy nhập email trước khi đặt lại mật khẩu."); return; } setBusy(true); setError(null); try { await sendPasswordResetEmail(firebaseAuth, email.trim()); setError("Đã gửi email đặt lại mật khẩu. Hãy kiểm tra hộp thư."); } catch (authError) { setError(firebaseErrorMessage(authError)); } finally { setBusy(false); } };
  return <Dialog open={open} onOpenChange={(nextOpen) => { if (!busy) { onOpenChange(nextOpen); if (!nextOpen) setError(null); } }}><DialogContent className="max-w-md rounded-3xl p-6 sm:p-8"><DialogHeader><div className="mx-auto mb-3 grid h-12 w-12 place-items-center rounded-2xl bg-secondary text-primary"><Mail className="h-6 w-6" /></div><DialogTitle className="text-center font-serif text-3xl">Đăng nhập AQizzy</DialogTitle><DialogDescription className="text-center leading-6">Lưu tiến độ và tiếp tục session đang luyện.</DialogDescription></DialogHeader><div className="mt-4 grid grid-cols-2 rounded-xl bg-muted p-1"><button type="button" onClick={() => { setMode("signin"); setError(null); }} className={`rounded-lg px-3 py-2 text-sm font-semibold ${mode === "signin" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>Đăng nhập</button><button type="button" onClick={() => { setMode("signup"); setError(null); }} className={`rounded-lg px-3 py-2 text-sm font-semibold ${mode === "signup" ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}>Tạo tài khoản</button></div><Button type="button" variant="outline" size="lg" onClick={signInGoogle} disabled={busy} className="mt-4 w-full"><Chrome className="mr-2 h-4 w-4" />{busy ? "Đang xử lý…" : "Tiếp tục với Google"}</Button><div className="my-5 flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" /><span>hoặc dùng email</span><span className="h-px flex-1 bg-border" /></div><form onSubmit={submitEmail} className="space-y-4"><div className="space-y-2"><Label htmlFor="aqizzy-email">Email</Label><Input id="aqizzy-email" type="email" autoComplete="email" value={email} onChange={(event) => setEmail(event.target.value)} placeholder="em@example.com" disabled={busy} /></div><div className="space-y-2"><div className="flex items-center justify-between"><Label htmlFor="aqizzy-password">Mật khẩu</Label>{mode === "signin" && <button type="button" onClick={resetPassword} className="text-xs font-semibold text-primary hover:underline" disabled={busy}>Quên mật khẩu?</button>}</div><Input id="aqizzy-password" type="password" autoComplete={mode === "signin" ? "current-password" : "new-password"} value={password} onChange={(event) => setPassword(event.target.value)} placeholder="Ít nhất 6 ký tự" disabled={busy} /></div>{error && <div className="flex gap-2 rounded-xl border border-destructive/25 bg-destructive/5 p-3 text-sm leading-5 text-destructive"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><span>{error}</span></div>}<Button type="submit" size="lg" className="w-full" disabled={busy}>{busy && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}{mode === "signin" ? "Đăng nhập bằng email" : "Tạo tài khoản bằng email"}</Button></form></DialogContent></Dialog>;
}
