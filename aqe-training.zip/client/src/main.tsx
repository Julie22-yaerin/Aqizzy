import { trpc } from "@/lib/trpc";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { httpBatchLink, TRPCClientError } from "@trpc/client";
import { createRoot } from "react-dom/client";
import superjson from "superjson";
import App from "./App";
import { firebaseAuth } from "./lib/firebase";
import "./index.css";

const queryClient = new QueryClient();

const logApiError = (error: unknown) => {
  if (error instanceof TRPCClientError) console.error("[API Query Error]", error.message);
};
queryClient.getQueryCache().subscribe((event) => { if (event.type === "updated" && event.action.type === "error") logApiError(event.query.state.error); });
queryClient.getMutationCache().subscribe((event) => { if (event.type === "updated" && event.action.type === "error") logApiError(event.mutation.state.error); });

const trpcClient = trpc.createClient({ links: [httpBatchLink({
  url: "/api/trpc",
  transformer: superjson,
  async headers() {
    const currentUser = firebaseAuth.currentUser;
    if (!currentUser) return {};
    try { return { Authorization: `Bearer ${await currentUser.getIdToken()}` }; } catch { return {}; }
  },
  fetch(input, init) { return globalThis.fetch(input, { ...(init ?? {}), credentials: "include" }); },
})] });

createRoot(document.getElementById("root")!).render(<trpc.Provider client={trpcClient} queryClient={queryClient}><QueryClientProvider client={queryClient}><App /></QueryClientProvider></trpc.Provider>);
