import { getAnalytics, isSupported } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { initializeApp } from "firebase/app";

export const firebaseConfig = {
  apiKey: "AIzaSyAU7tndPshfmNNClBNZA3WbBBGzbmzRWI4",
  authDomain: "pclick-9f190.firebaseapp.com",
  projectId: "pclick-9f190",
  storageBucket: "pclick-9f190.firebasestorage.app",
  messagingSenderId: "43342438061",
  appId: "1:43342438061:web:2b9e5019339e6cf0e87024",
  measurementId: "G-H8BF2M6ERM",
};

export const firebaseApp = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(firebaseApp);

if (typeof window !== "undefined") {
  void isSupported().then((supported) => {
    if (supported) getAnalytics(firebaseApp);
  }).catch(() => {
    // Analytics is optional; authentication must continue even when unsupported.
  });
}
