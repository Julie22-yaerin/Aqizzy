import { firebaseAuth } from "@/lib/firebase";
import { trpc } from "@/lib/trpc";
import { signOut, onAuthStateChanged, type User as FirebaseUser } from "firebase/auth";
import { useCallback, useEffect, useState } from "react";

type UseAuthOptions = { redirectOnUnauthenticated?: boolean; redirectPath?: string };

export function useAuth(_options?: UseAuthOptions) {
  const utils = trpc.useUtils();
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  useEffect(() => onAuthStateChanged(firebaseAuth, (nextUser) => { setFirebaseUser(nextUser); setAuthLoading(false); }), []);
  const meQuery = trpc.auth.me.useQuery(undefined, { enabled: Boolean(firebaseUser), retry: false, refetchOnWindowFocus: false });
  const logout = useCallback(async () => { await signOut(firebaseAuth); utils.auth.me.setData(undefined, null); await utils.auth.me.invalidate(); }, [utils]);
  const user = meQuery.data ?? null;
  useEffect(() => { if (user) localStorage.setItem("aqizzy-user-info", JSON.stringify(user)); else localStorage.removeItem("aqizzy-user-info"); }, [user]);
  return { user, firebaseUser, loading: authLoading || Boolean(firebaseUser && meQuery.isLoading), error: meQuery.error ?? null, isAuthenticated: Boolean(user), refresh: () => meQuery.refetch(), logout };
}
