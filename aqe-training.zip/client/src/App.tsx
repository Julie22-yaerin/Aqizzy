import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import Admin from "@/pages/Admin";
import Dashboard from "@/pages/Dashboard";
import History from "@/pages/History";
import Home from "@/pages/Home";
import NotFound from "@/pages/NotFound";
import Summary from "@/pages/Summary";
import TrainingSession from "@/pages/TrainingSession";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { AuthDialogProvider } from "./contexts/AuthContext";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() { return <Switch><Route path="/" component={Home} /><Route path="/dashboard" component={Dashboard} /><Route path="/session/:number" component={TrainingSession} /><Route path="/history" component={History} /><Route path="/summary" component={Summary} /><Route path="/admin" component={Admin} /><Route path="/admin/questions" component={Admin} /><Route path="/404" component={NotFound} /><Route component={NotFound} /></Switch>; }

function App() { return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><AuthDialogProvider><Toaster /><Router /></AuthDialogProvider></TooltipProvider></ThemeProvider></ErrorBoundary>; }
export default App;
