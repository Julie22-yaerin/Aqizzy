import { describe, expect, it } from "vitest";
import { CURRICULUM, isCorrectAnswer } from "./curriculum";

describe("A-QE curriculum", () => {
  it("delivers a fixed complete sequence of 24 sessions across eight weeks", () => {
    expect(CURRICULUM).toHaveLength(24);
    expect(CURRICULUM.map((session) => session.number)).toEqual(Array.from({ length: 24 }, (_, index) => index + 1));
    expect(new Set(CURRICULUM.map((session) => session.week))).toEqual(new Set([1, 2, 3, 4, 5, 6, 7, 8]));
  });

  it("gives every session the structured primary and recovery challenge content", () => {
    for (const session of CURRICULUM) {
      expect(session.introduction.length).toBeGreaterThan(20);
      expect(session.question.questionText.length).toBeGreaterThan(10);
      expect(session.question.acceptedAnswers.length).toBeGreaterThan(0);
      expect(session.question.hint1.length).toBeGreaterThan(5);
      expect(session.question.hint2.length).toBeGreaterThan(5);
      expect(session.question.hint3.length).toBeGreaterThan(5);
      expect(session.question.recoveryQuestion.length).toBeGreaterThan(10);
      expect(session.question.recoveryAnswers.length).toBeGreaterThan(0);
    }
  });

  it("checks structured answers without treating simple formatting differences as wrong", () => {
    expect(isCorrectAnswer(" 5 / 8 ", ["5/8"])).toBe(true);
    expect(isCorrectAnswer("$30", ["30", "$30"])).toBe(true);
    expect(isCorrectAnswer("idk", ["24"])).toBe(false);
  });
});
