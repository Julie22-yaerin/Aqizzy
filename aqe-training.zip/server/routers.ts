import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";
import {
  assignAdminQuestion,
  completeStudentSession,
  createAdminQuestion,
  deleteAdminQuestion,
  getAdminQuestions,
  getProgramSession,
  revealStudentSolution,
  getStudentDashboard,
  getStudentSummary,
  openStudentSession,
  requestStudentHint,
  submitStudentAttempt,
  updateAdminQuestion,
} from "./db";
import { CURRICULUM } from "../shared/curriculum";

const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== "admin") throw new TRPCError({ code: "FORBIDDEN", message: "Cần quyền quản trị để truy cập." });
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  training: router({
    curriculum: publicProcedure.query(() => CURRICULUM.map(({ question, ...session }) => ({
      ...session,
      subject: question.subject,
      difficulty: question.difficulty,
    }))),
    dashboard: protectedProcedure.query(({ ctx }) => getStudentDashboard(ctx.user.id)),
    session: protectedProcedure.input(z.object({ sessionNumber: z.number().int().min(1).max(24) }))
      .query(async ({ ctx, input }) => {
        await openStudentSession(ctx.user.id, input.sessionNumber);
        const session = await getProgramSession(input.sessionNumber);
        if (!session) return null;
        const { acceptedAnswers, recoveryAnswers, hint1, hint2, hint3, solution, recoverySolution, ...publicQuestion } = session.question;
        return { ...session, question: publicQuestion };
      }),
    submitAttempt: protectedProcedure.input(z.object({
      sessionNumber: z.number().int().min(1).max(24),
      stage: z.enum(["primary", "recovery"]),
      answer: z.string().max(500),
      hintNumber: z.number().int().min(0).max(3),
      timeSpentSeconds: z.number().min(0).max(3600),
    })).mutation(({ ctx, input }) => submitStudentAttempt({ studentId: ctx.user.id, ...input })),
    requestHint: protectedProcedure.input(z.object({
      sessionNumber: z.number().int().min(1).max(24),
      hintNumber: z.number().int().min(1).max(3),
    })).mutation(({ ctx, input }) => requestStudentHint(ctx.user.id, input.sessionNumber, input.hintNumber)),
    revealSolution: protectedProcedure.input(z.object({
      sessionNumber: z.number().int().min(1).max(24),
      stage: z.enum(["primary", "recovery"]),
    })).mutation(({ ctx, input }) => revealStudentSolution(ctx.user.id, input.sessionNumber, input.stage)),
    complete: protectedProcedure.input(z.object({
      sessionNumber: z.number().int().min(1).max(24),
      durationSeconds: z.number().min(0).max(3600),
      reflectionAction: z.string().max(120).optional(),
      differentApproach: z.enum(["Yes", "No", "Not sure"]).optional(),
    })).mutation(({ ctx, input }) => completeStudentSession({ studentId: ctx.user.id, ...input })),
    summary: protectedProcedure.query(({ ctx }) => getStudentSummary(ctx.user.id)),
  }),
  admin: router({
    questions: adminProcedure.query(() => getAdminQuestions()),
    updateQuestion: adminProcedure.input(z.object({
      questionId: z.string().min(1),
      subject: z.string().min(1).max(80).optional(),
      difficulty: z.number().int().min(1).max(3).optional(),
      persistenceTarget: z.string().min(1).max(64).optional(),
      questionText: z.string().min(1).max(4000).optional(),
      hint1: z.string().min(1).max(1500).optional(),
      hint2: z.string().min(1).max(1500).optional(),
      hint3: z.string().min(1).max(1500).optional(),
      solution: z.string().min(1).max(2000).optional(),
    })).mutation(({ input }) => updateAdminQuestion(input.questionId, input)),
    createQuestion: adminProcedure.input(z.object({
      sessionNumber: z.number().int().min(1).max(24),
      subject: z.string().min(1).max(80),
      difficulty: z.number().int().min(1).max(3),
      persistenceTarget: z.string().min(1).max(64),
      questionText: z.string().min(1).max(4000),
      acceptedAnswers: z.array(z.string().min(1).max(300)).min(1),
      hint1: z.string().min(1).max(1500),
      hint2: z.string().min(1).max(1500),
      hint3: z.string().min(1).max(1500),
      solution: z.string().min(1).max(2000),
      recoveryQuestion: z.string().min(1).max(2500),
      recoveryAnswers: z.array(z.string().min(1).max(300)).min(1),
      recoverySolution: z.string().min(1).max(2000),
    })).mutation(({ input }) => createAdminQuestion(input)),
    assignQuestion: adminProcedure.input(z.object({
      questionId: z.string().min(1),
      sessionNumber: z.number().int().min(1).max(24),
    })).mutation(({ input }) => assignAdminQuestion(input.questionId, input.sessionNumber)),
    deleteQuestion: adminProcedure.input(z.object({ questionId: z.string().min(1) }))
      .mutation(({ input }) => deleteAdminQuestion(input.questionId)),
  }),
});

export type AppRouter = typeof appRouter;
