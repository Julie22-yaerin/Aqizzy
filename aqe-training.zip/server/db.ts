import { and, asc, eq, sql } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  attempts,
  curriculumSessions,
  InsertUser,
  questions,
  studentSessions,
  users,
} from "../drizzle/schema";
import {
  CURRICULUM,
  getCurriculumSession,
  isCorrectAnswer,
  type CurriculumSession,
  type TrainingQuestion,
} from "../shared/curriculum";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;
let seedPromise: Promise<void> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) return;

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  for (const field of ["name", "email", "loginMethod"] as const) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  values.lastSignedIn = user.lastSignedIn ?? new Date();
  updateSet.lastSignedIn = values.lastSignedIn;
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

/** Inserts the fixed 24-session program only when records do not already exist. */
export async function seedCurriculum() {
  if (seedPromise) return seedPromise;
  seedPromise = (async () => {
    const db = await getDb();
    if (!db) return;
    for (const session of CURRICULUM) {
      await db.insert(curriculumSessions).values({
        id: session.id,
        week: session.week,
        sessionNumber: session.number,
        title: session.title,
        persistenceTarget: session.target,
        introduction: session.introduction,
      }).onDuplicateKeyUpdate({ set: {
        week: session.week,
        sessionNumber: session.number,
        title: session.title,
        persistenceTarget: session.target,
        introduction: session.introduction,
      } });
      const question = session.question;
      await db.insert(questions).values({
        id: question.id,
        sessionId: session.id,
        subject: question.subject,
        gradeBand: question.gradeBand,
        difficulty: question.difficulty,
        persistenceTarget: question.persistenceTarget,
        questionText: question.questionText,
        answerType: question.answerType,
        acceptedAnswers: question.acceptedAnswers,
        hint1: question.hint1,
        hint2: question.hint2,
        hint3: question.hint3,
        solution: question.solution,
        recoveryQuestion: question.recoveryQuestion,
        recoveryAnswers: question.recoveryAnswers,
        recoverySolution: question.recoverySolution,
      }).onDuplicateKeyUpdate({ set: {
        sessionId: question.id === session.question.id ? session.id : session.id,
        subject: question.subject,
        gradeBand: question.gradeBand,
        difficulty: question.difficulty,
        persistenceTarget: question.persistenceTarget,
        questionText: question.questionText,
        answerType: question.answerType,
        acceptedAnswers: question.acceptedAnswers,
        hint1: question.hint1,
        hint2: question.hint2,
        hint3: question.hint3,
        solution: question.solution,
        recoveryQuestion: question.recoveryQuestion,
        recoveryAnswers: question.recoveryAnswers,
        recoverySolution: question.recoverySolution,
      } });
    }
  })();
  return seedPromise;
}

function asQuestion(row: typeof questions.$inferSelect): TrainingQuestion {
  return {
    id: row.id,
    subject: row.subject as TrainingQuestion["subject"],
    gradeBand: row.gradeBand as "Lớp 6–8",
    difficulty: row.difficulty as 1 | 2 | 3,
    persistenceTarget: row.persistenceTarget as TrainingQuestion["persistenceTarget"],
    questionText: row.questionText,
    answerType: "short_text",
    acceptedAnswers: row.acceptedAnswers as string[],
    hint1: row.hint1,
    hint2: row.hint2,
    hint3: row.hint3,
    solution: row.solution,
    recoveryQuestion: row.recoveryQuestion,
    recoveryAnswers: row.recoveryAnswers as string[],
    recoverySolution: row.recoverySolution,
  };
}

export async function getProgramSession(sessionNumber: number): Promise<CurriculumSession | null> {
  await seedCurriculum();
  const db = await getDb();
  const fallback = getCurriculumSession(sessionNumber);
  if (!db || !fallback) return fallback ?? null;
  const [sessionRow] = await db.select().from(curriculumSessions)
    .where(eq(curriculumSessions.sessionNumber, sessionNumber)).limit(1);
  const [questionRow] = await db.select().from(questions)
    .where(eq(questions.id, sessionRow?.activeQuestionId || fallback.question.id)).limit(1);
  if (!sessionRow || !questionRow) return fallback;
  return {
    id: sessionRow.id,
    number: sessionRow.sessionNumber,
    week: sessionRow.week,
    title: sessionRow.title,
    target: sessionRow.persistenceTarget as CurriculumSession["target"],
    introduction: sessionRow.introduction,
    question: asQuestion(questionRow),
  };
}

export async function openStudentSession(studentId: number, sessionNumber: number) {
  const db = await getDb();
  const program = await getProgramSession(sessionNumber);
  if (!db || !program) throw new Error("Không tìm thấy session luyện tập.");
  await db.insert(studentSessions).values({
    studentId,
    sessionId: program.id,
    week: program.week,
    sessionNumber: program.number,
  }).onDuplicateKeyUpdate({ set: { sessionId: sql`${studentSessions.sessionId}` } });
  const [studentSession] = await db.select().from(studentSessions)
    .where(and(eq(studentSessions.studentId, studentId), eq(studentSessions.sessionId, program.id))).limit(1);
  if (!studentSession) throw new Error("Không thể mở session luyện tập.");
  return { program, studentSession };
}

function classifyAttempt(answer: string, previousAnswers: string[]) {
  const trimmed = answer.trim().toLowerCase();
  if (!trimmed || ["idk", "i dont know", "i don't know", "dont know", "don't know", "no idea", "không biết", "khong biet", "ko biết", "chưa biết"].includes(trimmed)) return "NO_ATTEMPT" as const;
  if (trimmed.length < 2 || previousAnswers.some((previous) => previous.trim().toLowerCase() === trimmed)) return "MINIMAL_ATTEMPT" as const;
  if (previousAnswers.length > 0) return "STRATEGY_CHANGE" as const;
  return "MEANINGFUL_ATTEMPT" as const;
}

export async function submitStudentAttempt(input: {
  studentId: number;
  sessionNumber: number;
  stage: "primary" | "recovery";
  answer: string;
  hintNumber: number;
  timeSpentSeconds: number;
}) {
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const { program, studentSession } = await openStudentSession(input.studentId, input.sessionNumber);
  if (studentSession.completed) throw new Error("Session này đã được hoàn thành.");
  const question = program.question;
  const previous = await db.select().from(attempts).where(and(
    eq(attempts.studentSessionId, studentSession.id),
    eq(attempts.stage, input.stage),
  )).orderBy(asc(attempts.attemptNumber));
  const previousAnswers = previous.map((attempt) => attempt.answer);
  const classification = classifyAttempt(input.answer, previousAnswers);
  const correctness = input.stage === "primary"
    ? isCorrectAnswer(input.answer, question.acceptedAnswers)
    : isCorrectAnswer(input.answer, question.recoveryAnswers);
  const attemptNumber = previous.length + 1;
  const strategyChanged = classification === "STRATEGY_CHANGE";
  await db.insert(attempts).values({
    studentId: input.studentId,
    studentSessionId: studentSession.id,
    questionId: question.id,
    stage: input.stage,
    attemptNumber,
    timestampMs: Date.now(),
    timeSpentSeconds: Math.max(0, Math.round(input.timeSpentSeconds)),
    answer: input.answer.trim(),
    correctness,
    hintRequested: input.hintNumber > 0,
    hintNumber: input.hintNumber,
    strategyChanged,
    meaningfulAttempt: classification,
  });
  await db.update(studentSessions).set({
    attemptCount: sql`${studentSessions.attemptCount} + 1`,
    meaningfulAttemptCount: classification === "MEANINGFUL_ATTEMPT" || classification === "STRATEGY_CHANGE"
      ? sql`${studentSessions.meaningfulAttemptCount} + 1`
      : sql`${studentSessions.meaningfulAttemptCount}`,
    strategyChanges: strategyChanged ? sql`${studentSessions.strategyChanges} + 1` : sql`${studentSessions.strategyChanges}`,
    recoveryCompleted: input.stage === "recovery" && correctness ? true : studentSession.recoveryCompleted,
  }).where(eq(studentSessions.id, studentSession.id));
  return {
    correct: correctness,
    attemptNumber,
    meaningful: classification !== "NO_ATTEMPT" && classification !== "MINIMAL_ATTEMPT",
    strategyChanged,
    canRequestHint: input.stage === "primary" && !correctness && input.hintNumber < 3,
      feedback: correctness
      ? "Em đã tìm được một câu trả lời phù hợp. Tiếp theo, hãy thử thử thách phục hồi."
      : classification === "NO_ATTEMPT"
        ? "Hãy viết ra bất kỳ ý tưởng nào em có. Một bước chưa hoàn chỉnh vẫn cho em điểm bắt đầu để làm tiếp."
        : "Câu trả lời này chưa hiệu quả. Hãy thử một cách khác trước khi chuyển sang việc khác.",
  };
}

export async function requestStudentHint(studentId: number, sessionNumber: number, hintNumber: number) {
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const { program, studentSession } = await openStudentSession(studentId, sessionNumber);
  if (studentSession.completed) throw new Error("Session này đã được hoàn thành.");
  const hints = [program.question.hint1, program.question.hint2, program.question.hint3];
  const safeHintNumber = Math.min(3, Math.max(1, hintNumber));
  await db.update(studentSessions).set({ hintsUsed: sql`${studentSessions.hintsUsed} + 1` })
    .where(eq(studentSessions.id, studentSession.id));
  return { hintNumber: safeHintNumber, hint: hints[safeHintNumber - 1] };
}

export async function revealStudentSolution(studentId: number, sessionNumber: number, stage: "primary" | "recovery") {
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const { program, studentSession } = await openStudentSession(studentId, sessionNumber);
  const loggedAttempts = await db.select().from(attempts).where(and(
    eq(attempts.studentSessionId, studentSession.id),
    eq(attempts.stage, stage),
  ));
  const minimumAttempts = stage === "primary" ? 2 : 1;
  if (loggedAttempts.length < minimumAttempts) throw new Error("Hãy thực hiện thêm một lần thử trước khi xem lời giải.");
  return { solution: stage === "primary" ? program.question.solution : program.question.recoverySolution };
}

export async function completeStudentSession(input: {
  studentId: number;
  sessionNumber: number;
  durationSeconds: number;
  reflectionAction?: string;
  differentApproach?: string;
}) {
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const { studentSession } = await openStudentSession(input.studentId, input.sessionNumber);
  await db.update(studentSessions).set({
    completed: true,
    completedAt: new Date(),
    durationSeconds: Math.max(0, Math.round(input.durationSeconds)),
    reflectionResponse: { action: input.reflectionAction, differentApproach: input.differentApproach },
  }).where(eq(studentSessions.id, studentSession.id));
  return getStudentDashboard(input.studentId);
}

function roundRate(numerator: number, denominator: number) {
  return denominator ? Math.round((numerator / denominator) * 100) : 0;
}

export async function getStudentDashboard(studentId: number) {
  await seedCurriculum();
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const sessions = await db.select().from(studentSessions)
    .where(eq(studentSessions.studentId, studentId)).orderBy(asc(studentSessions.sessionNumber));
  const allAttempts = await db.select().from(attempts).where(eq(attempts.studentId, studentId));
  const completed = sessions.filter((session) => session.completed);
  const completedNumbers = new Set(completed.map((session) => session.sessionNumber));
  const nextSession = CURRICULUM.find((session) => !completedNumbers.has(session.number)) ?? CURRICULUM[23];
  const currentWeekCompleted = completed.filter((session) => session.week === nextSession.week).length;
  const meaningful = allAttempts.filter((attempt) => ["MEANINGFUL_ATTEMPT", "STRATEGY_CHANGE"].includes(attempt.meaningfulAttempt)).length;
  const secondAttempts = allAttempts.filter((attempt) => attempt.attemptNumber >= 2).length;
  const incorrect = allAttempts.filter((attempt) => !attempt.correctness).length;
  const laterAttempts = allAttempts.filter((attempt) => attempt.attemptNumber >= 2 && attempt.correctness).length;
  const strategyChanges = allAttempts.filter((attempt) => attempt.strategyChanged).length;
  const hintsAfterAttempt = allAttempts.filter((attempt) => attempt.hintNumber > 0 && attempt.attemptNumber > 1).length;
  const recoverySessions = completed.filter((session) => session.recoveryCompleted).length;
  let stage = { level: 1, label: "Em nhận ra điều khó", description: "Em đang học cách nhận ra khi một câu hỏi trở nên thử thách." };
  if (completed.length >= 18 && strategyChanges >= 3 && recoverySessions >= 3) stage = { level: 6, label: "Em kiên trì độc lập", description: "Em đang dùng nhiều công cụ kiên trì trong những thử thách mới." };
  else if (recoverySessions >= 2) stage = { level: 5, label: "Em phục hồi", description: "Em quay lại nhiệm vụ sau một sai lầm và tiếp tục làm." };
  else if (strategyChanges >= 2) stage = { level: 4, label: "Em đổi chiến lược", description: "Em đang thử một lối khác khi câu trả lời chưa hiệu quả." };
  else if (secondAttempts >= 2) stage = { level: 3, label: "Em thử lại", description: "Em đang thực hiện thêm một lần thử có ý nghĩa sau khi gặp khó." };
  else if (meaningful >= 1 || completed.length >= 1) stage = { level: 2, label: "Em ở lại", description: "Em đang ở lại với bài đủ lâu để thực hiện một lần thử." };
  const recentBehaviors = [
    secondAttempts > 0 && "Đã thử lại",
    strategyChanges > 0 && "Đã đổi chiến lược",
    recoverySessions > 0 && "Đã phục hồi sau sai lầm",
    hintsAfterAttempt > 0 && "Đã nhờ hỗ trợ sau khi cố gắng",
  ].filter(Boolean) as string[];
  return {
    current: { week: nextSession.week, sessionNumber: nextSession.number, sessionTitle: nextSession.title, weekCompleted: currentWeekCompleted, totalCompleted: completed.length },
    stage,
    recentBehaviors: recentBehaviors.length ? recentBehaviors : ["Lần thử có ý nghĩa đầu tiên của em sẽ xuất hiện ở đây."],
    history: CURRICULUM.map((session) => ({ ...session, completed: completedNumbers.has(session.number) })),
    metrics: {
      persistenceAttemptRate: roundRate(meaningful, allAttempts.length),
      secondAttemptRate: roundRate(secondAttempts, allAttempts.length),
      errorRecoveryRate: roundRate(laterAttempts, incorrect),
      strategySwitchRate: roundRate(strategyChanges, allAttempts.length),
      delayedHelpRate: roundRate(hintsAfterAttempt, allAttempts.filter((attempt) => attempt.hintNumber > 0).length),
      challengeCompletionRate: roundRate(completed.length, CURRICULUM.length),
    },
    hasFinishedProgram: completed.length === CURRICULUM.length,
  };
}

export async function getStudentSummary(studentId: number) {
  const dashboard = await getStudentDashboard(studentId);
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const attemptRecords = await db.select({ attempt: attempts, sessionNumber: studentSessions.sessionNumber })
    .from(attempts)
    .innerJoin(studentSessions, eq(attempts.studentSessionId, studentSessions.id))
    .where(eq(attempts.studentId, studentId));
  const compare = (items: (typeof attempts.$inferSelect)[]) => ({
    averageAttemptsAfterDifficulty: items.length ? Number((items.reduce((sum, attempt) => sum + attempt.attemptNumber, 0) / items.length).toFixed(1)) : 0,
    strategyChanges: items.filter((attempt) => attempt.strategyChanged).length,
    helpBeforeAttempting: items.filter((attempt) => attempt.hintNumber > 0 && attempt.attemptNumber === 1).length,
    recoveryAfterMistakes: items.filter((attempt) => attempt.stage === "recovery" && attempt.correctness).length,
  });
  const early = attemptRecords.filter((record) => record.sessionNumber <= 3).map((record) => record.attempt);
  const final = attemptRecords.filter((record) => record.sessionNumber >= 22).map((record) => record.attempt);
  return { dashboard, early: compare(early), final: compare(final) };
}

export async function getAdminQuestions() {
  await seedCurriculum();
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const rows = await db.select().from(questions).orderBy(asc(questions.id));
  const allAttempts = await db.select().from(attempts);
  return rows.map((question) => {
    const related = allAttempts.filter((attempt) => attempt.questionId === question.id);
    return {
      ...question,
      acceptedAnswers: question.acceptedAnswers as string[],
      recoveryAnswers: question.recoveryAnswers as string[],
      stats: {
        attempts: related.length,
        hintUsage: related.filter((attempt) => attempt.hintRequested).length,
        completionRate: related.length ? roundRate(related.filter((attempt) => attempt.correctness).length, related.length) : 0,
      },
    };
  });
}

export async function updateAdminQuestion(questionId: string, values: Partial<{
  subject: string; difficulty: number; persistenceTarget: string; questionText: string; hint1: string; hint2: string; hint3: string; solution: string;
}>) {
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const [existing] = await db.select().from(questions).where(eq(questions.id, questionId)).limit(1);
  if (!existing) throw new Error("Không tìm thấy câu hỏi.");
  await db.update(questions).set({
    subject: values.subject ?? existing.subject,
    difficulty: values.difficulty ?? existing.difficulty,
    persistenceTarget: values.persistenceTarget ?? existing.persistenceTarget,
    questionText: values.questionText ?? existing.questionText,
    hint1: values.hint1 ?? existing.hint1,
    hint2: values.hint2 ?? existing.hint2,
    hint3: values.hint3 ?? existing.hint3,
    solution: values.solution ?? existing.solution,
  }).where(eq(questions.id, questionId));
  return { success: true };
}

export async function createAdminQuestion(input: {
  sessionNumber: number;
  subject: string;
  difficulty: number;
  persistenceTarget: string;
  questionText: string;
  acceptedAnswers: string[];
  hint1: string;
  hint2: string;
  hint3: string;
  solution: string;
  recoveryQuestion: string;
  recoveryAnswers: string[];
  recoverySolution: string;
}) {
  await seedCurriculum();
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const [session] = await db.select().from(curriculumSessions)
    .where(eq(curriculumSessions.sessionNumber, input.sessionNumber)).limit(1);
  if (!session) throw new Error("Không tìm thấy session.");
  const id = `admin-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
  await db.insert(questions).values({
    id,
    sessionId: session.id,
    subject: input.subject,
    gradeBand: "6–8",
    difficulty: input.difficulty,
    persistenceTarget: input.persistenceTarget,
    questionText: input.questionText,
    answerType: "short_text",
    acceptedAnswers: input.acceptedAnswers,
    hint1: input.hint1,
    hint2: input.hint2,
    hint3: input.hint3,
    solution: input.solution,
    recoveryQuestion: input.recoveryQuestion,
    recoveryAnswers: input.recoveryAnswers,
    recoverySolution: input.recoverySolution,
  });
  return { id, success: true };
}

export async function assignAdminQuestion(questionId: string, sessionNumber: number) {
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  const [question] = await db.select().from(questions).where(eq(questions.id, questionId)).limit(1);
  const [session] = await db.select().from(curriculumSessions)
    .where(eq(curriculumSessions.sessionNumber, sessionNumber)).limit(1);
  if (!question || !session) throw new Error("Không tìm thấy câu hỏi hoặc session.");
  await db.update(questions).set({ sessionId: session.id }).where(eq(questions.id, questionId));
  await db.update(curriculumSessions).set({ activeQuestionId: questionId }).where(eq(curriculumSessions.id, session.id));
  return { success: true };
}

export async function deleteAdminQuestion(questionId: string) {
  if (!questionId.startsWith("admin-")) throw new Error("Không thể xóa câu hỏi có sẵn trong lộ trình.");
  const db = await getDb();
  if (!db) throw new Error("Không thể kết nối cơ sở dữ liệu.");
  await db.update(curriculumSessions).set({ activeQuestionId: null })
    .where(eq(curriculumSessions.activeQuestionId, questionId));
  await db.delete(questions).where(eq(questions.id, questionId));
  return { success: true };
}
